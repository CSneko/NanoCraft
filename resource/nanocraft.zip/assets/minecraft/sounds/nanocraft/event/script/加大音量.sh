for file in *.ogg; do
    ffmpeg -i "$file" -af "volume=10dB" "${file%.ogg}_temp.ogg" && mv "${file%.ogg}_temp.ogg" "$file"
done

